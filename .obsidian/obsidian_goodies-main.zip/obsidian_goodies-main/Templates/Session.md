
# Session N

## Scene 1

### Scene Setting

- Expectation:
- Chaos Factor:
- Alteration roll:

### Game