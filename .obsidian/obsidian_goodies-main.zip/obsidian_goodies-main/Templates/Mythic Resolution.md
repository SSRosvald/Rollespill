# Resolution Box

|***QUESTION:***|  ?|
|---|---|
|_Notes:_|   |
|**Acting Rank:**|   |
|**Difficulty Rank:**|   |
|Modifiers:|   |
|**RESULTS**|   |
|Yes:|   |
|No:|   |
|Yes!+:|   |
|No!+:|   |



