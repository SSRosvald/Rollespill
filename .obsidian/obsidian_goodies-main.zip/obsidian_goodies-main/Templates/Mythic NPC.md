# NPC
***NAME: ***
**Strength:**
**Agility:**
**Reflex:**
**IQ:**
**Intuition:**
**Willpower:**
**Toughness:**