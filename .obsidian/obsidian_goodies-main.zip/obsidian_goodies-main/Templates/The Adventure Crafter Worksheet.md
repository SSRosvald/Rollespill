# The Adventure Crafter Worksheet

## Adventure Notes

## Themes

| 1d10 | #   | Theme |
| ---- | --- | ----- |
| 1-4  | 1   |       |
| 5-7  | 2   |       |
| 8-9  | 3   |       |
| 10   | 4   |       |
| 10   | 5   |       |

## Turning Points

| Turning<br>Point | Plot Type | Plot Line |
|:----------------:| --------- | --------- |
|        1         | New       |           |

| #   | Plot Points       | Characters Invoked          |
| --- | ----------------- | --------------------------- |
| 1   | Something Happens | Mr. Someone McSomethingface |
| 2   |                   |                             |
| 3   |                   |                             |
| 4   |                   |                             |
| 5   |                   |                             | 
 
* `Notes`:
