# Wound

|**CHARACTER:**|   |
|---|---|
|Wound Description:|   |
|**Type:**|Lethal / Bashing   |
|Body Area:|   |
|**Wound Rank:**|   |
|Wound Effect:|   |
|When to check for healing:|   |


