| Turning Point | Plot Type | Plot Line |
| ------------- | --------- | --------- |
|               |           |           |

| #   | Plot Points | Characters Invoked |
| --- | ----------- | ------------------ |
| 1   |             |                    |
| 2   |             |                    |
| 3   |             |                    |
| 4   |             |                    |
| 5   |             |                    |
 
* `Notes`:
