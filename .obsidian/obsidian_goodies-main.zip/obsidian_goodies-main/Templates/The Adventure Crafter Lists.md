# The Adventure Crafter Lists

The filled in cells are defaults. As new plot lines and characters are introduced, replace the cell with that information. This is used when rolling on the lists.

| 1d100  | Plotlines    | Characters   |
| ------ | ------------ | ------------ |
| 1-4    | Most Logical | New          |
| 5-8    | New          | New          |
| 9-12   | Most Logical | New          |
| 13-16  | Most Logical | Most Logical |
| 17-20  | Most Logical | New          |
| 21-24  | New          | New          |
| 25-28  | Most Logical | New          |
| 29-32  | Most Logical | Most Logical |
| 33-36  | Most Logical | New          |
| 37-40  | New          | New          |
| 41-44  | Most Logical | New          |
| 45-48  | Most Logical | Most Logical |
| 49-52  | Most Logical | New          |
| 53-56  | New          | Most Logical |
| 57-60  | Most Logical | Most Logical |
| 61-64  | Most Logical | Most Logical |
| 65-68  | Most Logical | New          |
| 69-72  | New          | Most Logical |
| 73-76  | Most Logical | Most Logical |
| 77-80  | Most Logical | Most Logical |
| 81-84  | Most Logical | New          |
| 85-88  | New          | Most Logical |
| 89-92  | Most Logical | Most Logical |
| 93-96  | Most Logical | Most Logical |
| 97-100 | Most Logical | New          | 
