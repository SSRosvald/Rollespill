# Scaling Box
**CONCEPT:**

|**Description**|**Mythic Rank**|
|---|---|
|   |.   |
|   |Minuscule|
|    |Weak|
|    |Low|
|    |Below Average|
|    |_Average_|
|    |Above Average|
|    |High|
|    |Exceptional|
|    |Incredible|
|   |Awesome|
|    |.   |
|    |.   |