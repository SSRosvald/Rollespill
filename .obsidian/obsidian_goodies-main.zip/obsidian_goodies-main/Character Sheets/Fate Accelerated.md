# Character Name

```ad-abstract
title: ID

- **Name**:
- **Description**:

| Refresh | Current Fate Points |
| ------- | ------------------- |
|         |                     |
```
```ad-abstract
title: Aspects

- **High Concept**:
- **Trouble**:
```

```ad-abstract
title: Approaches

| Careful | Clever | Flashy | Forceful | Quick | Sneaky |
| ------- | ------ | ------ | -------- | ----- | ------ |
|         |        |        |          |       |        |

```

```ad-abstract
title: Stunts

```

```ad-abstract
title: Stress & Consequences

| 1   | 2   | 3   | Mild (2) | Moderate (4) | Severe (6) | 
| --- | --- | --- | -------- | ------------ | ---------- |
|     |     |     |          |              |            |


```
