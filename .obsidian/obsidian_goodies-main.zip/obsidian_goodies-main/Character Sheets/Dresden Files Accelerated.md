# NAME

## Aspects

- High Concept:
- Trouble:
- Other Aspects:

## Approaches

| Flair | Focus | Force | Guile | Haste | Intellect |
|-------|-------|-------|-------|-------|-----------|
|       |       |       |       |       |           |

## Mantles


## Stunts

## Stress

[ ] [ ] [ ] [ ] [ ] [ ] [ ]

## Conditions

[4] In Peril
[6] Doomed
[ ] [ ] [ ] [ ] [ ] Indebted

## Refresh