---
tags:
  - Genesys
---

# {{ character name }}

## Details

| Detail                | Value |
| --------------------- | ----- |
| Species<br/>Archetype |       |
| Career                |       |
| Gender                |       |
| Age                   |       |
| Height                |       |
| Build                 |       |
| Hair                  |       |
| Eyes                  |       |
| Player                |       |

---

## Characteristics

| Brawn | Agility | Intellect | Cunning | Willpower | Presence |
| ----- | ------- | --------- | ------- | --------- | -------- |
| 0     | 0       | 0         | 0       | 0         | 0        |

---

## Derived Stats

| Stat    | Current | Threshold |
| ------- | ------- | --------- |
| Soak    | 0       | -         |
| Wounds  | 0       | 0         |
| Strain  | 0       | 0         |
| Defense | R/0     | M/0       |

---

## Skills

### General Skills

| Skill                  | #   | Pool    |
| ---------------------- | --- | ------- |
| Alchemy (INT)          | 0   | &#9671; |
| Astrocartography (INT) | 0   | &#9671; |
| Athletics (BR)         | 0   | &#9671; |
| Computers (INT)        | 0   | &#9671; |
| Cool (PR)              | 0   | &#9671; |
| Coordination (AG)      | 0   | &#9671; |
| Discipline (Will)      | 0   | &#9671; |
| Driving (AG)           | 0   | &#9671; |
| Mechanics (INT)        | 0   | &#9671; |
| Medicine (INT)         | 0   | &#9671; |
| Operating (INT)        | 0   | &#9671; |
| Perception (CUN)       | 0   | &#9671; |
| Piloting (AG)          | 0   | &#9671; |
| Resilience (BR)        | 0   | &#9671; |
| Riding (AG)            | 0   | &#9671; |
| Skulduggery (CUN)      | 0   | &#9671; |
| Stealth (AG)           | 0   | &#9671; |
| Streetwise (CUN)       | 0   | &#9671; |
| Vigilance (WILL)       | 0   | &#9671; |

### Social Skills

| Skill            | #   | Pool    |
| ---------------- | --- | ------- |
| Charm (PR)       | 0   | &#9671; |
| Coercion (WILL)  | 0   | &#9671; |
| Deception (CUN)  | 0   | &#9671; |
| Leadership (PR)  | 0   | &#9671; |
| Negotiation (PR) | 0   | &#9671; |

### Combat Skills

| Skill             | #   | Pool    |
| ----------------- | --- | ------- |
| Brawl (BR)        | 0   | &#9671; |
| Gunnery (AG)      | 0   | &#9671; |
| Melee (BR)        | 0   | &#9671; |
| Melee-Light (BR)  | 0   | &#9671; |
| Melee-Heavy (BR)  | 0   | &#9671; |
| Ranged (AG)       | 0   | &#9671; |
| Ranged-Light (AG) | 0   | &#9671; |
| Ranged-Heavt (AG) | 0   | &#9671; |

### Knowledge Skills

| Skill           | #   | Pool    |
| --------------- | --- | ------- |
| Knowledge (INT) | 0   | &#9671; |

### Magic Skills

| Skill         | #   | Pool    |
| ------------- | --- | ------- |
| Arcana (INT)  | 0   | &#9671; |
| Divine (WILL) | 0   | &#9671; |
| Primal (CUN)  | 0   | &#9671; |

## Weapons

| Name  | Skill | Dam | Crit | Range   | Special |
| ----- | ----- | --- | ---- | ------- | ------- |
| Knife | BR    | 3   | 4    | Engaged |         |

---

## Motivations 

### Strengths 

### Flaw

### Desire

### Fear

---

## Equipment Log

---

## Critical Injuries

---

## Special Abilities

---

## Talents

### Tier 1 Talents (7)

### Tier 2 Talents (6)

### Tier 3 Talents (5)

### Tier 4 Talents (4)

### Tier 5 Talents (3)

---

## XP

| Total XP | Available XP |
| -------- | ------------ |
| 0        | 0            |

---

## XP Log

---