# Player Character
***NAME:***
_Favor Points:_

#### Character Summary

#### Atributes
|Atribute|Rank|
|---|---|
|**Strength:**|   |
|**Agility:**|   |
|**Reflex:**|   |
|**IQ:**|   |
|**Intuition:**|   |
|**Willpower:**|   |
|**Toughness:**|   |
|.   |   |

#### Abilities
|Ability|Rank|
|---|---|
|.   |   |
|.   |   |
|.   |   |
|.   |   |
|.   |   |

#### Strengths & Weaknesses
- 

#### Notes

#### Personal Threads
- 
#### Personal Characters
- 

