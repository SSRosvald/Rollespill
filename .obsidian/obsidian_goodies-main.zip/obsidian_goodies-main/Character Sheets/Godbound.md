Intro

Godbound of level . Bound to...

## Stats


| Strength | Dexterity | Constitution | Intelligence | Wisdom | Charisma |
| -------- | --------- | ------------ | ------------ | ------ | -------- | 
|          |           |              |              |        |          |

| Saving Throws | Base | Mod | Armor | Final            |
| ------------- | ---- | --- | ----- | ---------------- |
| Hardiness     | 15   | 0   | 0     | 1 : `dice: 1d20` |
| Evasion       | 15   | 0   | 0     | 1 : `dice: 1d20` |
| Spirit        | 15   | 0   | 0     | 1 : `dice: 1d20` | 

### Resources

|       | Effort | Influence | Dominion | Health | AC  |
| ----- | ------ | --------- | -------- | ------ | --- |
| Total |        |           |          |        |     |
| Free  |        |           |          |        |     |

### Attacks

| Attack           | To Hit Bonus | Stat | Damage |
| ---------------- | ------------ | ---- | ------ |


### Gifts


